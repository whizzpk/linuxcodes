#!/bin/sh

#main which runs all otehr scripts one by one

./i2cv1.0.sh
./memoryv1.0.sh
./pci1.0.sh
./pcistresstest.sh
./sdhciv1.0.sh
./usbv1.0.sh
./videocardv1.0.sh
